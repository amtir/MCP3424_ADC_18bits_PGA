Credits
=======

"MCP342x" is written and maintained by Steve Marple.


Contributors
------------

- jrm224 https://github.com/jrm224

Please append your name here when you submit your first pull request.
